def calc_tax():
    pass

def calc_shipping():
    pass


class Price:
    def write(self):
        print('aaa')